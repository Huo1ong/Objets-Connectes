/**
    Class MyOledViewWorking
    @file MyOledViewWorking.h 
    @author Guillou Quentin
    @version 1.1 21/09/20 
**/


#ifndef MYOLEDVIEWWORKING_H
#define MYOLEDVIEWWORKING_H

#include "MyOledView.h"

#include <Adafruit_SSD1306.h>
#include <string>

class MyOledViewWorking : public MyOledView {
    
    public:
        void init(std::string _id);
        std::string id();

    protected:
        void display( Adafruit_SSD1306 *adafruit);
        void update(Adafruit_SSD1306 *adafruit);
        void displayGifFire();
        void displayGifFireAnimated();

        unsigned char *Fire24x24Pointers[6];
        static int IndexFire;
        static int IndexFireDelay ;
};
#endif