/**
    Gestion d'une VUE pour le OLed  
    @file MyOledViewWorking.cpp
    @author GUILLOU Quentin
    @version 1.1 21/09/20 
*/
#include <Arduino.h>
#include "MyOledViewWorking.h"

using namespace std;


int MyOledViewWorking::IndexFire = 0;
int MyOledViewWorking::IndexFireDelay = 0;

void MyOledViewWorking::display(Adafruit_SSD1306 *adafruit)
{

    adafruit->display();
}

void MyOledViewWorking::update(Adafruit_SSD1306 *adafruit)
{
    display(adafruit);
}