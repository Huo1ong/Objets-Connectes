/**
    Gestion d'une VUE pour le OLed  
    @file MyOledViewWorkingCOLD.cpp
    @author GUILLOU Quentin
    @version 1.1 21/09/20 
*/
#include <Arduino.h>
#include "MyOledViewWorkingCOLD.h"

using namespace std;

void MyOledViewWorkingCOLD::display(Adafruit_SSD1306 *adafruit)
{
    adafruit->display();

}
void MyOledViewWorkingCOLD::update(Adafruit_SSD1306 *adafruit)
{
    display(adafruit);
}