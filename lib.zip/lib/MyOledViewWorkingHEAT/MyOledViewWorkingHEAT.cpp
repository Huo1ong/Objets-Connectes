/**
    Gestion d'une VUE pour le OLed  
    @file MyOledVieWorkingHEAT.cpp
    @author GUILLOU Quentin
    @version 1.1 21/09/20 
*/
#include <Arduino.h>
#include "MyOledViewWorkingHEAT.h"

using namespace std;

void MyOledViewWorkingHEAT::display(Adafruit_SSD1306 *adafruit)
{
    adafruit->display();
}

void MyOledViewWorkingHEAT::update(Adafruit_SSD1306 *adafruit)
{
    display(adafruit);
}