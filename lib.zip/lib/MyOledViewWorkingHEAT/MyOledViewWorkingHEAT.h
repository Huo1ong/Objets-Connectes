/**
    Class MyOledViewWorkingHEAT : Gestion d'une VUE pour la température
    @file MyOledViewWorkingHEAT.h 
    @author GUILLOU Quentin
    @version 1.1 21/09/20 
**/


#ifndef MYOLEDVIEWWORKINGHEAT_H
#define MYOLEDVIEWWORKINGHEAT_H

#include <Adafruit_SSD1306.h>
#include <string>

#include "MyOledViewWorking.h"

class MyOledViewWorkingHEAT : public MyOledViewWorking
{
    private :
        virtual void display( Adafruit_SSD1306 *adafruit) = 0;
        virtual void update(Adafruit_SSD1306 *adafruit) = 0;
};
#endif