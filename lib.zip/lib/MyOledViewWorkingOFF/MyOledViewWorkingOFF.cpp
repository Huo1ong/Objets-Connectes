/**
    Gestion d'une VUE pour le OLed  
    @file MyOledViewWorkingOFF.cpp
    @author GUILLOU Quentin
    @version 1.1 21/09/20 
*/
#include <Arduino.h>
#include "MyOledViewWorkingOFF.h"

using namespace std;

  void MyOledViewWorkingOFF::setNomDuSysteme(std::string val)
  {
    nomdusysteme = val;
  }
  
  void MyOledViewWorkingOFF::setTempDuSysteme(std::string val)
  {
      tempdusysteme = val;
  }

  void MyOledViewWorkingOFF::setIPDuSysteme(std::string val)
  {
      ipdusysteme = val;
  }

void MyOledViewWorkingOFF::display(Adafruit_SSD1306 *adafruit)
{
    char strIP[120];
    char strTemp[120];
    sprintf(strIP, tempdusysteme.c_str());
    sprintf(strTemp, ipdusysteme.c_str());

    adafruit->clearDisplay();

    adafruit->setCursor(0, 0);
    adafruit->setTextSize(2);
    adafruit->println("SAC system");
    adafruit->setTextSize(1);
    adafruit->println("Id : 1303");
    adafruit->println("Ready");
    adafruit->println(strIP);
    adafruit->println(strTemp);

    adafruit->display();
}           