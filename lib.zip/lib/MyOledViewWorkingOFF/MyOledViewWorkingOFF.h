/**
    Class MyOledViewWorkingOFF
    @file MyOledViewWorkingOFF.h 
    @author GUILLOU Quentin
    @version 1.1 21/09/20 
**/


#ifndef MYOLEDVIEWWORKINGOFF_H
#define MYOLEDVIEWWORKINGOFF_H

#include <Adafruit_SSD1306.h>
#include <string>

#include "MyOledViewWorking.h"

class MyOledViewWorkingOFF : public MyOledViewWorking
{
    public :
        void setNomDuSysteme(std::string val);
        void setTempDuSysteme(std::string val);
        void setIPDuSysteme(std::string val);

    private :
        void display( Adafruit_SSD1306 *adafruit);
        std::string nomdusysteme;
        std::string tempdusysteme;
        std::string ipdusysteme;


};
#endif