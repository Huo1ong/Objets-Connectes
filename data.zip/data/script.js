var arbre;
function get_all_arbre() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            // var arrayOfStrings = this.responseText.split("&");
            var arrayOfStrings = JSON.parse(this.responseText);
            console.log(this.responseText);
            console.log(arrayOfStrings);
            console.log(arrayOfStrings.rows.length);
            arbre =  arrayOfStrings.rows;
            for (var i = 0; i < arrayOfStrings.rows.length; i=i+1) {
                var x = document.getElementById("NomBois");
                var option = document.createElement("option");
                option.value = i;
                option.text = arrayOfStrings.rows[i]["NomBois"];
                console.log(option.value);
                console.log(option.text);
                // console.log(arrayOfStrings.text[i]);
                x.appendChild(option);
                console.log(x);
               
                } 
           
            //Refresh le contenu
            var siteHeader = document.getElementById('typeBois_ListBox_Select');
            siteHeader.style.display='none';
            siteHeader.offsetHeight; // no need to store this anywhere, the reference is enough
            siteHeader.style.display='block';

            }
    };
    xhttp.open("GET", "http://172.16.205.252:3000/get-all-arbre", true);
    xhttp.send();
}

var temp;
var lesbois;
